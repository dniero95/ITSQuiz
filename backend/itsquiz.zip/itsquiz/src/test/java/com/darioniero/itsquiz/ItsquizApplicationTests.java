package com.darioniero.itsquiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItsquizApplicationTests {

	@Test
	void contextLoads() {
	}

}
